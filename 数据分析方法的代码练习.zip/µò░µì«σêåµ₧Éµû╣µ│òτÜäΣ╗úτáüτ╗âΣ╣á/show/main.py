import pandas as pd
df = pd.read_csv('./data/HR.csv')
df.head(10)
import scipy.stats as ss


